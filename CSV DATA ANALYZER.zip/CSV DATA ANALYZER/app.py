import pandas as pd
import streamlit as st
from dotenv import load_dotenv
import os
import google.generativeai as genai

load_dotenv()
google_api_key = os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=google_api_key)

def analyze_csv(file):
    df = pd.read_csv(file)
    summary = df.describe(include='all')
    return df, summary

def extract_column(df, attribute):
    attribute = attribute.lower()
    matching_columns = [col for col in df.columns if col.lower() == attribute]
    if matching_columns:
        return df[matching_columns[0]]
    else:
        return pd.Series()

def generate_response(prompt):
    try:
        model = genai.GenerativeModel('gemini-pro')
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        st.error(f"Error generating response: {e}")
        if "429" in str(e):
            st.error("The API quota has been exhausted. Please try again later.")
        return ""

st.set_page_config(page_title="CSV Analysis")
st.header("CSV Analysis Application")
uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])

if uploaded_file:
    df, summary = analyze_csv(uploaded_file)
    st.subheader("CSV Summary")
    st.write(summary)

    column = st.text_input("Enter the column name to display:")
    
    if column:
        extracted_column = extract_column(df, column)
        if not extracted_column.empty:
            st.subheader(f"Data from column: {column}")
            st.write(extracted_column)
            
            response_prompt = f"Here is the data from the column {column}:\n{extracted_column.to_string()}\n\nPlease provide insights based on this data."
            response = generate_response(response_prompt)
            if response:
                st.subheader("Generated Insights")
                st.write(response)
        else:
            st.write(f"Column '{column}' not found in the dataset.")
    
    if st.button("Generate Conclusion for Entire Dataset"):
        response_prompt = f"Here is the summary of the dataset:\n{summary.to_string()}\n\nPlease provide a conclusion based on this dataset."
        conclusion = generate_response(response_prompt)
        if conclusion:
            st.subheader("Generated Conclusion")
            st.write(conclusion)

    question = st.text_input("Enter your question about the dataset:")
    if question and st.button("Ask Question"):
        question_prompt = f"Here is the summary of the dataset:\n{summary.to_string()}\n\nQuestion: {question}"
        answer = generate_response(question_prompt)
        if answer:
            st.subheader("Generated Answer")
            st.write(answer)
else:
    st.write("Please upload a CSV file to analyze the data.")
